console.log("=== CEP ===");

(function () {

  // User Interface
  const UI = {
    fieldCep: document.querySelector("#cep")
  };

  // Actions
  const onlyNumbers = function(e) {
    this.value = this.value.replace(/\D/gi, "");

    if (this.value.length > 8) {
      this.value = this.value.slice(0, 8);
    }
  };
  
  const validateEntry = function() {
    console.log(this.value);

    if (this.value.length < 8) {
      this.classList.add("error");
      this.focus();
    } else {
      this.classList.remove("error");
      getAddress(this.value);
    }
  };
  
  const getAddress = async function(cep) {
    const endpoint = `https://viacep.com.br/ws/${cep}/json/`;
    console.log(endpoint);

    const config = {
      method: "GET",
      headers: new Headers({
        "Content-type": "application/json"
      })
    };

    const response = await fetch(endpoint, config);
    const address = await response.json();

    getAddressSuccess(address);
  };


  const getAddressSuccess = function(endereco) {
    console.log(endereco.logradouro);
  }

  // Binding Events
  UI.fieldCep.addEventListener("input", onlyNumbers); // onlyNumbers(InputEvent);
  UI.fieldCep.addEventListener("focusout", validateEntry);

  


  console.log(UI);
})();
