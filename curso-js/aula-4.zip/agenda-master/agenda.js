(function () {
  console.log("=== AGENDA ===");

  // User Interface
  const UI = {
    fieldName: document.querySelector("#name"),
    fieldEmail: document.querySelector("#email"),
    fields: document.querySelectorAll("input"),
    buttonAdd: document.querySelector(".pure-button-primary"),
    tableData: document.querySelector(".pure-table")
  };
  console.log(UI);

  // Actions
  const validateFields = function(e) {
    e.preventDefault();
    // console.log(e); // console.log(arguments[0]);

    UI.fields.forEach(function (field) {
      
      // console.log(field.value, field.value === "", field.value.length);

      if (field.value.length > 0) {
        console.log(field.id, "foi preenchido!");

        field.classList.remove("error");
      } else {
        console.log(field.id, "não foi!");

        field.classList.add("error");
      }


    });


  };

  const addContact = function() {};

  const getContacts = function() {};

  const showContacts = function() {};

  const removeContact = function() {};

  // Binding Events
  UI.buttonAdd.onclick = validateFields; // validateFields(MouseEvent);



})();
