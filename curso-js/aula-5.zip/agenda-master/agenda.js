(function () {
  console.log("=== AGENDA ===");

  // User Interface
  const UI = {
    fieldName: document.querySelector("#name"),
    fieldEmail: document.querySelector("#email"),
    fields: document.querySelectorAll("input"),
    buttonAdd: document.querySelector(".pure-button-primary"),
    tableData: document.querySelector(".pure-table tbody")
  };
  // console.log(UI);

  // Actions
  const validateFields = function(e) {
    e.preventDefault();
    let errors = 0;
    let contact = {};

    UI.fields.forEach(function (field) {
      if (field.value.trim().length > 0) {
        // console.log(field.id, "foi preenchido!");
        field.classList.remove("error");
        contact[field.id] = field.value;
      } else {
        // console.log(field.id, "não foi!");
        field.classList.add("error");
        errors++;
      }
    });

    if (errors === 0) {
      addContact(contact);
    } else {
      document.querySelector(".error").focus();
    }
  };

  const addContact = function(contact) {
    const endpoint = "http://localhost:7000/contacts";

    const config = {
      method: "POST",
      body: JSON.stringify(contact),
      headers: new Headers({
        "Content-type": "application/json"
      })
    };
    
    fetch(endpoint, config)
      .then(addContactSuccess) // fulfilled
      .catch(addContactError); // rejected
  };

  const addContactSuccess = function() {
    clearFields();
    getContacts();
  };

  const addContactError = function() {
    console.error("Falha ao salvar o contato!");
  };

  const clearFields = function() {
    UI.fields.forEach(function(field) {
      field.value = "";
    });

    UI.fieldName.focus();
  };

  const getContacts = function() {
    const endpoint = "http://localhost:7000/contacts";

    const config = {
      method: "GET",
      headers: new Headers({
        "Content-type": "application/json"
      })
    };
    
    fetch(endpoint, config) // promise 1
      .then(transformToJson) // fulfilled promise 1
        .then(getContactsSuccess) // fulfilled promise 2
        .catch(getContactsError) // rejected promise 2
      .catch(getContactsError) // rejected promise 1
  };

  const getContactsError = function() {
    console.error("Falha ao recuperar os contatos!");
  };

  const transformToJson = function(response) {
    return response.json(); // promise 2
  };

  const getContactsSuccess = function(contacts) {
    const htmlTable = 
      contacts
        // .filter(function(contact) { return contact.id <= 3; })
        .map(function(contact) {
          return `<tr>
                    <td>${contact.id}</td>
                    <td>${contact.name}</td>
                    <td>${contact.email}</td>
                    <td>${contact.phone}</td>
                    <td><a href="#">Excluir</a></td>
                </tr>`;
        })
        .join("");

    UI.tableData.innerHTML = htmlTable;
  };

  const removeContact = function() {};

  // Binding Events
  UI.buttonAdd.onclick = validateFields; // validateFields(MouseEvent);

  // Initialize
  getContacts();

})();
